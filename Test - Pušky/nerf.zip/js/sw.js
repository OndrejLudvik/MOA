//pro práci offline a ukládání do cache
//OBSANO Z GITHUBU NEJDE
const CACHE_NAME = "v1";
const cacheAssets = [
  "/",
  "/index.html",
  "/css/style.css",
  "/js/app.js",
  "/Haiset.png",
  "/HaisetHigh.png",
  "/img/LongStrike.png",
  "/img/LongStrikeWithBarrel.png",
  "/img/LongStrikeWithScope.png",
  "/img/LongStrikeWithScopeAndBarrel.png"
];

self.addEventListener("install", e => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log("Caching files");
        return cache.addAll(cacheAssets);
      })
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cache => {
          if (cache !== CACHE_NAME) {
            console.log("Removing old cache", cache);
            return caches.delete(cache);
          }
        })
      );
    })
  );
});

self.addEventListener("fetch", e => {
  e.respondWith(
    fetch(e.request).catch(() => caches.match(e.request))
  );
});
